//
//  commandLine.hpp
//  MSDscript
//
//  Created by Randi Prince on 1/15/23.
//

#ifndef commandLine_hpp
#define commandLine_hpp

#include <stdio.h>
#include <iostream>

void use_arguments(int argc, char * argv[]);

#endif /* commandLine_hpp */
